// ============================================================
// زمین کویر غنی: تپه‌شکن + کوه‌های لبه + رنگ‌بندی چندلایه + صخره‌ها + باند
// یک بار ساخته می‌شود؛ getHeight از گرید مش مکمل نمونه‌گیری می‌کند
// ============================================================
import * as THREE from 'three';
import { makeNoise2D, fbm, clamp, lerp, smoothstep } from '../utils.js';
import { WORLD, BASES } from '../config.js';

export class Terrain {
  constructor(scene, quality) {
    this.size = WORLD.size;
    this.seg = quality.terrainSeg;
    this.n = this.seg + 1;
    this.half = this.size / 2;
    this.step = this.size / this.seg;
    this.noise = makeNoise2D(WORLD.seed);
    this.heights = new Float32Array(this.n * this.n);

    this._buildHeightfield();
    this._buildMesh(scene, quality);
    this._buildRocks(scene, quality);
    this._buildTrees(scene, quality);
    this._buildBase(scene);
  }

  // ---------- ارتفاع ----------
  _flatten(h, x, z, cx, cz, r, elev) {
    const d = Math.hypot(x - cx, z - cz);
    if (d >= r * 1.5) return h;
    return lerp(elev, h, smoothstep(r, r * 1.5, d));
  }

  _baseHeight(x, z) {
    const s = this.size;
    const nx = (x / s) * 46, nz = (z / s) * 46;
    // تپه‌های شنی
    let h = fbm(this.noise, nx, nz, 5) * 26;
    // رشته‌های پهن
    h += Math.abs(fbm(this.noise, nx * 0.32 + 9.2, nz * 0.32 + 3.1, 3)) * 42;
    // دره‌های خشک (منفی)
    const wadi = fbm(this.noise, nx * 1.4 + 51, nz * 1.4 + 17, 3);
    if (wadi < -0.22) h += (wadi + 0.22) * 34;
    // جزئیات
    h += fbm(this.noise, nx * 6 + 40, nz * 6 + 11, 2) * 4;
    h += 30;
    // کوه‌های حاشیه تیز و صخره‌ای برای بستن افق (ریج‌د — خط‌الرأس تیز)
    const edge = Math.max(Math.abs(x), Math.abs(z)) / this.half;
    const wall = smoothstep(0.68, 1.0, edge);
    const ridge = 1 - Math.abs(fbm(this.noise, nx * 2 + 99, nz * 2 + 7, 4));
    const ridge2 = 1 - Math.abs(fbm(this.noise, nx * 5 + 17, nz * 5 + 41, 3));
    h += wall * wall * (240 + ridge * ridge * 300 + ridge2 * 70);
    // هموارسازی بیس‌ها
    h = this._flatten(h, x, z, BASES.friendly.x, BASES.friendly.z, 950, BASES.friendly.elev);
    h = this._flatten(h, x, z, BASES.enemy.x, BASES.enemy.z, 950, BASES.enemy.elev);
    return h;
  }

  _buildHeightfield() {
    for (let j = 0; j < this.n; j++) {
      const z = -this.half + j * this.step;
      for (let i = 0; i < this.n; i++) {
        this.heights[j * this.n + i] = this._baseHeight(-this.half + i * this.step, z);
      }
    }
  }

  getHeight(x, z) {
    const fx = clamp((x + this.half) / this.step, 0, this.seg - 1e-4);
    const fz = clamp((z + this.half) / this.step, 0, this.seg - 1e-4);
    const i = fx | 0, j = fz | 0;
    const tx = fx - i, tz = fz - j;
    const h00 = this.heights[j * this.n + i];
    const h10 = this.heights[j * this.n + i + 1];
    const h01 = this.heights[(j + 1) * this.n + i];
    const h11 = this.heights[(j + 1) * this.n + i + 1];
    return lerp(lerp(h00, h10, tx), lerp(h01, h11, tx), tz);
  }

  // ---------- مش با رنگ چندلایه ----------
  _buildMesh(scene, quality) {
    const geo = new THREE.PlaneGeometry(this.size, this.size, this.seg, this.seg);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const c = new THREE.Color();

    for (let k = 0; k < pos.count; k++) {
      const x = pos.getX(k), z = pos.getZ(k);
      const h = this._baseHeight(x, z);
      pos.setY(k, h);

      const hx = this._baseHeight(x + this.step, z) - h;
      const hz = this._baseHeight(x, z + this.step) - h;
      const slope = Math.min(1, (Math.abs(hx) + Math.abs(hz)) / (this.step * 0.26));
      const mott = fbm(this.noise, x * 0.0045 + 77, z * 0.0045 + 13, 3);
      const streak = fbm(this.noise, x * 0.0012 - 5, z * 0.012 + 31, 2); // موج شن

      // پالت غنی کویری: شن گرم اشباع → موج → کف نمکی → صخره سرخ → قله
      c.setRGB(
        0.74 + mott * 0.09 + streak * 0.06,
        0.60 + mott * 0.08 + streak * 0.05,
        0.40 + mott * 0.05,
      );
      if (h < 34) c.lerp(_cSalt, clamp((34 - h) / 16, 0, 1) * 0.8);
      if (h > 95) c.lerp(_cHigh, clamp((h - 95) / 60, 0, 1) * 0.72);
      c.lerp(_cRock, slope * 0.92);
      if (h > 150) c.lerp(_cPeak, clamp((h - 150) / 120, 0, 1) * 0.85);
      c.convertSRGBToLinear();
      colors[k * 3] = c.r; colors[k * 3 + 1] = c.g; colors[k * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    // بافت جزئیات شن (دانه + لکه) — نزدیک دوربین بافت زمین را «زمین» می‌کند
    const detail = _detailTexture();
    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      map: detail,
      bumpMap: detail,
      bumpScale: 0.55,
      roughness: 0.97,
      metalness: 0,
    });
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.receiveShadow = true;
    scene.add(this.mesh);
  }

  // ---------- صخره‌های پراکنده (اینستنس — یک دراکال) ----------
  _buildRocks(scene, quality) {
    const count = quality.rocks;
    const geo = new THREE.DodecahedronGeometry(1, 0);
    const mat = new THREE.MeshStandardMaterial({ color: 0x8a7660, roughness: 1, flatShading: true });
    const inst = new THREE.InstancedMesh(geo, mat, count);
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    let placed = 0, guard = 0;
    while (placed < count && guard++ < count * 8) {
      const x = (Math.random() * 2 - 1) * this.half * 0.9;
      const z = (Math.random() * 2 - 1) * this.half * 0.9;
      if (Math.hypot(x - BASES.friendly.x, z - BASES.friendly.z) < 1100) continue;
      if (Math.hypot(x - BASES.enemy.x, z - BASES.enemy.z) < 1100) continue;
      const h = this._baseHeight(x, z);
      if (h > 130) continue; // روی قله نیست
      const s = 2.5 + Math.random() * Math.random() * 9;
      pos.set(x, h + s * 0.25, z);
      scl.set(s, s * (0.6 + Math.random() * 0.7), s);
      q.setFromEuler(new THREE.Euler(0, Math.random() * 6.28, 0));
      m4.compose(pos, q, scl);
      inst.setMatrixAt(placed++, m4);
    }
    inst.count = placed;
    inst.castShadow = true;
    inst.receiveShadow = true;
    scene.add(inst);
  }

  // ---------- درخت‌های واحه (اینستنس — خوشه‌ای کنار وادی‌ها) ----------
  _buildTrees(scene, quality) {
    const count = quality.trees || 0;
    if (count <= 0) return;
    const trunkGeo = new THREE.CylinderGeometry(0.35, 0.55, 6, 5);
    const crownGeo = new THREE.SphereGeometry(3.2, 6, 5);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c452e, roughness: 1, flatShading: true });
    const crownMat = new THREE.MeshStandardMaterial({ color: 0x4a6b35, roughness: 1, flatShading: true });
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, count);
    const crowns = new THREE.InstancedMesh(crownGeo, crownMat, count);
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();

    // خوشه واحه‌ها: جایی که وادی عمیق است
    const clusters = [];
    for (let c = 0; c < 26; c++) {
      const x = (Math.random() * 2 - 1) * this.half * 0.8;
      const z = (Math.random() * 2 - 1) * this.half * 0.8;
      const nx = (x / this.size) * 46, nz = (z / this.size) * 46;
      const wadi = fbm(this.noise, nx * 1.4 + 51, nz * 1.4 + 17, 3);
      const h = this._baseHeight(x, z);
      if (h > 40 && h < 130 && wadi < -0.1) clusters.push([x, z]);
    }
    if (!clusters.length) clusters.push([BASES.friendly.x + 1600, BASES.friendly.z + 900]);

    let placed = 0, guard = 0;
    while (placed < count && guard++ < count * 10) {
      const cl = clusters[(Math.random() * clusters.length) | 0];
      const x = cl[0] + (Math.random() * 2 - 1) * 260;
      const z = cl[1] + (Math.random() * 2 - 1) * 260;
      if (Math.hypot(x - BASES.friendly.x, z - BASES.friendly.z) < 1000) continue;
      if (Math.hypot(x - BASES.enemy.x, z - BASES.enemy.z) < 1000) continue;
      const h = this._baseHeight(x, z);
      if (h > 130 || h < 26) continue;
      const s = 0.7 + Math.random() * 0.9;
      pos.set(x, h + 3 * s, z);
      scl.set(s, s, s);
      q.setFromEuler(new THREE.Euler(0, Math.random() * 6.28, 0));
      m4.compose(pos, q, scl);
      trunks.setMatrixAt(placed, m4);
      pos.y = h + 6.4 * s;
      scl.set(s * (0.8 + Math.random() * 0.4), s * (0.7 + Math.random() * 0.5), s * (0.8 + Math.random() * 0.4));
      m4.compose(pos, q, scl);
      crowns.setMatrixAt(placed, m4);
      placed++;
    }
    trunks.count = placed;
    crowns.count = placed;
    trunks.castShadow = crowns.castShadow = true;
    scene.add(trunks, crowns);
  }

  // ---------- بیس متفقین: باند + سکو + چراغ ----------
  _buildBase(scene) {
    const B = BASES.friendly;
    const y = B.elev;

    const rw = new THREE.Mesh(
      new THREE.PlaneGeometry(46, 2600),
      new THREE.MeshStandardMaterial({
        map: _runwayTexture(), roughness: 0.95, metalness: 0,
        polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
      })
    );
    rw.rotation.x = -Math.PI / 2;
    rw.position.set(B.x, y + 0.22, B.z);
    rw.receiveShadow = true;
    scene.add(rw);

    const apron = new THREE.Mesh(
      new THREE.PlaneGeometry(200, 160),
      new THREE.MeshStandardMaterial({
        color: 0x6b6b66, roughness: 1,
        polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
      })
    );
    apron.rotation.x = -Math.PI / 2;
    apron.position.set(B.x + 140, y + 0.2, B.z - 1050);
    apron.receiveShadow = true;
    scene.add(apron);

    // هانگارهای متفقین (تزئینی)
    for (let i = 0; i < 3; i++) {
      const hangar = new THREE.Mesh(
        new THREE.BoxGeometry(42, 14, 34),
        new THREE.MeshStandardMaterial({ color: 0x77715f, roughness: 0.9 })
      );
      hangar.position.set(B.x + 130, y + 7, B.z - 960 + i * 55);
      hangar.castShadow = true;
      scene.add(hangar);
    }

    // چراغ‌های لبه باند
    const count = 2 * Math.ceil(2600 / 65) + 2;
    const lights = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.55, 6, 4),
      new THREE.MeshBasicMaterial({ color: 0xfff2b0 }),
      count
    );
    const m4 = new THREE.Matrix4();
    let idx = 0;
    for (let d = -1300; d <= 1300 && idx < count; d += 65) {
      m4.makeTranslation(B.x - 23.5, y + 0.5, B.z + d);
      lights.setMatrixAt(idx++, m4);
      m4.makeTranslation(B.x + 23.5, y + 0.5, B.z + d);
      lights.setMatrixAt(idx++, m4);
    }
    lights.count = idx;
    scene.add(lights);
  }
}

const _cSalt = new THREE.Color(0.70, 0.66, 0.58);
const _cRock = new THREE.Color(0.42, 0.33, 0.27);
const _cHigh = new THREE.Color(0.55, 0.45, 0.36);
const _cPeak = new THREE.Color(0.80, 0.78, 0.76);

// بافت جزئیات — دانه‌های شن + لکه‌های محو (نزدیک‌کلیف ۱۰۰× تکرار)
function _detailTexture() {
  const cv = document.createElement('canvas');
  cv.width = cv.height = 256;
  const g = cv.getContext('2d');
  g.fillStyle = '#c9c2b4';
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i++) {
    const v = 175 + (Math.random() * 70) | 0;
    g.fillStyle = `rgba(${v},${v - 6},${v - 18},${0.12 + Math.random() * 0.2})`;
    const s = 1 + Math.random() * 2.4;
    g.fillRect(Math.random() * 256, Math.random() * 256, s, s);
  }
  // لکه‌های بزرگ محو (تنوع پوشش)
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * 256, y = Math.random() * 256, r = 14 + Math.random() * 44;
    const dark = Math.random() < 0.5;
    const gr = g.createRadialGradient(x, y, 1, x, y, r);
    gr.addColorStop(0, dark ? 'rgba(96,84,64,0.16)' : 'rgba(224,214,192,0.14)');
    gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr;
    g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(110, 110);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function _runwayTexture() {
  const cv = document.createElement('canvas');
  cv.width = 256; cv.height = 2048;
  const g = cv.getContext('2d');
  g.fillStyle = '#3d3f41';
  g.fillRect(0, 0, 256, 2048);
  for (let i = 0; i < 500; i++) {
    const v = 25 + (Math.random() * 28) | 0;
    g.fillStyle = `rgba(${v},${v},${v + 3},0.20)`;
    g.fillRect(Math.random() * 256, Math.random() * 2048, 2 + Math.random() * 42, 1 + Math.random() * 3);
  }
  g.strokeStyle = '#e6e6dc'; g.lineWidth = 4;
  g.beginPath();
  g.moveTo(14, 0); g.lineTo(14, 2048);
  g.moveTo(242, 0); g.lineTo(242, 2048);
  g.stroke();
  g.setLineDash([70, 50]); g.lineWidth = 6;
  g.beginPath(); g.moveTo(128, 0); g.lineTo(128, 2048); g.stroke();
  g.setLineDash([]);
  for (let i = 0; i < 8; i++) {
    const x = 30 + i * 26;
    g.fillRect(x, 28, 14, 92);
    g.fillRect(x, 2048 - 120, 14, 92);
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
